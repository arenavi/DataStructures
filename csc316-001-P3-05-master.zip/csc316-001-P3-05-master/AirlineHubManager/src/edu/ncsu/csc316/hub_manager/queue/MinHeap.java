/**
 * 
 */
package edu.ncsu.csc316.hub_manager.queue;

/**
 * Handles the functionality of Heap data structure for Kruskal's Algorithm.
 * @author Amiya Renavikar
 * @param <E> generic type
 */
public class MinHeap<E> {
	
	/** Stores the list of Heaps */
	@SuppressWarnings("unused")
	private E[] heap;
	/** Size of the list */
	@SuppressWarnings("unused")
	private int size;
	
	/**
	 * Constructs a MinHeap object.
	 */
	public MinHeap() {
		//do nothing
	}
	
}
