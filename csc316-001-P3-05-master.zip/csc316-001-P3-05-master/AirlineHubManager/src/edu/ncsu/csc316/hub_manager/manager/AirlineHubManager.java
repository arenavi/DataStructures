/**
 * 
 */
package edu.ncsu.csc316.hub_manager.manager;

/**
 * Manager class returns a string representation of the list of Flights,
 * and minimum spanning set of flights.
 * @author Amiya Renavikar
 */
public class AirlineHubManager {
	/**
	 * Constructs a new AirlineHubManager
	 * 
	 * @param pathToFile the path to the file that contains the airports
	 */
	public AirlineHubManager(String pathToFile)
	{
	    //do nothing
	}
	
	/**
	 * Returns a string representation of the list of Flights contained in the 
	 * minimum spanning set of flights that connect all airports. The returned string is in
	 * the following format, where the flights are sorted in increasing order
	 * by distance. If multiple flights have the same distance, order by airport code
	 * in ascending alphabetical order.
	 *  - Distance should be displayed to 1 decimal place
	 *  - Each flight line is indented by 3 spaces
	 * 
	 * FlightList[
	 *    Flight[airport1=ORH, airport2=RDU, distance=576.4],
	 *    Flight[airport1=SEA, airport2=SFO, distance=679.6],
	 *    Flight[airport1=MIA, airport2=RDU, distance=702.8],
	 *    Flight[airport1=DFW, airport2=RDU, distance=1059.7],
	 *    Flight[airport1=DFW, airport2=SFO, distance=1462.3]
	 * ]
	 * 
	 * @return a string representation of the minimum spanning set of flights
	 */
	public String getMinimumFlights()
	{
	    return null;
	}

	/**
	 * Returns the list of possible airport hubs (airports with at least 
	 * 3 connecting flights in the minimum spanning set of flights).
	 * The list should be output in the following format, where the
	 * airports are listed in descending order by number of connecting flights. 
	 * If multiple airports have the same number of connecting flights, order
	 * the airports alphabetically by airport code.
	 *  - Each airport line is indented by 3 spaces
	 *  
	 * HubReport[
	 *   RDU has 3 connections.
	 * ]
	 * 
	 * @return the string representation of the list of possible airport hubs
	 */
	public String getPossibleHubs()
	{
		return null;
	}


}
