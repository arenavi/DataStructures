/**
 * 
 */
package edu.ncsu.csc316.hub_manager.ui;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import edu.ncsu.csc316.hub_manager.manager.AirlineHubManager;

/**
 * This class acts as the User Interface for the Airline Hub Manager project.
 * @author Amiya Renavikar
 */
public class AirlineHubManagerUI {

	/**
	 * This is the main method of the AirlineHubManagerUI class.
	 * This method was implemented using parts of code from my projects 
	 * for CSC 116 and CSC 216, and Project 1 for CSC 316.
	 * @param args command line argument.
	 * @throws FileNotFoundException if file is not found
	 */
	@SuppressWarnings("unused")
	public static void main(String[] args) throws FileNotFoundException {
		//Import scanner
		Scanner sc = new Scanner(System.in);
		File airportFile = new File("");
		//Enter file names while airport, customer, and flight files are null
		while (airportFile == null) {
			System.out.print("Enter airport file name: ");	
			airportFile = new File(sc.next());
			//If file does not exist, set airport file to null and print message for re-prompt
			if (!airportFile.exists()) {
				airportFile = null;
				System.out.println("File does not exist!");
			}
		}
	
		//Create manager object
		AirlineHubManager amm = new AirlineHubManager(airportFile.getAbsolutePath());
		
		int flag = 0;
		while (flag == 0) {
			System.out.print("Please enter what action you wish to perform (to generate a list of flight connections - enter g, to produce an airport hub report - enter r, or to quit - enter q)");
			String command = sc.next();
			if (command.equalsIgnoreCase("g")) { 
				System.exit(0);
			} else if (command.equalsIgnoreCase("r")) {
				System.exit(0);
			} else if (command.equalsIgnoreCase("q")) {
				System.exit(0);
				flag = 1;
			} else {
				System.out.println("Command not found, please try again!");
			}
		}
		sc.close();
	}

}
