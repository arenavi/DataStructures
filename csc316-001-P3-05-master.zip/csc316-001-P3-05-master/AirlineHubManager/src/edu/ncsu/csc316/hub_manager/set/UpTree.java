/**
 * 
 */
package edu.ncsu.csc316.hub_manager.set;

import java.util.Arrays;

/**
 * Handles the functionality for Uptree data structure.
 * @author Amiya Renavikar
 */
public class UpTree {
	
	/** List of node pointers */
	private int[] uptree;
	/** Size of the list */
	@SuppressWarnings("unused")
	private int size;
	
	/**
	 * Constructs an UpTree object with its size.
	 * @param size size of uptree
	 */
	public UpTree(int size) {
		uptree = new int[size];
		Arrays.fill(uptree, -1);
	}

}
