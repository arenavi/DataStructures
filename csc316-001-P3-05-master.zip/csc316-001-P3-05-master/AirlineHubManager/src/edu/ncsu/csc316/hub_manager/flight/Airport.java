/**
 * 
 */
package edu.ncsu.csc316.hub_manager.flight;

/**
 * Creates an Airport object with airport code, latitude, and longitude of the airport.
 * @author Amiya Renavikar
 */
public class Airport {
	
	/** Airport code */
	public String code;
	/** Airport latitude */
	public double latitude;
	/** Airport longitude */
	public double longitude;

	/**
	 * Constructs an Airport object with its code, latitude, and longitude.
	 * @param code Airport code
	 * @param latitude Airport latitude
	 * @param longitude Airport longitude-
	 */
	public Airport(String code, double latitude, double longitude) {
		this.code = code;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	/**
	 * Returns the Airport code.
	 * @return code airport code
	 */
	public String getCode() {
		return code;
	}
	
	/**
	 * Returns the Airport latitude.
	 * @return latitude airport latitude
	 */
	public double getLatitude() {
		return latitude;
	}
	
	/**
	 * Returns the Airport longitude.
	 * @return longitude airport longitude
	 */
	public double getLongitude() {
		return longitude;
	}
}
