/**
 * 
 */
package edu.ncsu.csc316.hub_manager.graph;


/**
 * Creates an Adjacency List to store the list of airports.
 * @author Amiya Renavikar
 */
public class AdjacencyList {
	
	/** Stores the size of the list */
	@SuppressWarnings("unused")
	private int size;
	
	/**
	 * Constructs a AdjacencyList object and sets size to 0.
	 */
	public AdjacencyList() {
		size = 0;
	}
	

	/**
	 * Inner class to store Adjacency list edges.
	 * @author Amiya Renavikar
	 */
	/*private class Vertex {
		
		*//** Variable to store the airport data in an ArrayList *//*
		private Airport data;
		*//** Variable to store the flight distance *//*
		private double flightDistance;
		*//** Variable to store next vertex in list *//*
		private Vertex next;
		
		*//**
		 * Constructs the Node class by instantiating variables.
		 * @param data airport data in an ArrayList
		 * @param flightDistance flight distance
		 * @param next next vertex in the list
		 *//*
		@SuppressWarnings("unused")
		public Vertex (Airport data, double flightDistance, Vertex next) {
			this.data = data;
			this.flightDistance = flightDistance;
			this.next = next;
		}
	}*/
}
