/**
 * 
 */
package edu.ncsu.csc316.hub_manager.util;

import edu.ncsu.csc316.hub_manager.flight.Airport;
import edu.ncsu.csc316.hub_manager.list.ArrayList;
import edu.ncsu.csc316.hub_manager.queue.MinHeap;
import edu.ncsu.csc316.hub_manager.set.UpTree;

/**
 * Finds the shortest distance between two airports using Kruskal's algorithm.
 * Based on the implementation found in the CSC 316 textbook.
 * @author Amiya Renavikar
 */
public class MinimumSpanningTreeFinder {
	/** Stores the Minheap used in the algorithm. */
	@SuppressWarnings("unused")
	private MinHeap<Airport> minHeap;
	/** Stores the UpTree used in the algorithm. */
	@SuppressWarnings("unused")
	private UpTree upTree;
	/** Stores the number of vertices in graph */
	@SuppressWarnings("unused")
	private int v;
	/** List that stores edges */
	@SuppressWarnings("unused")
	private ArrayList<Airport> list;
	
	/**
	 * Constructs an object of MinimumSpanningTree class.
	 * @param v number of vertices in the graph
	 * @param minHeap Min Heap
	 */
	public MinimumSpanningTreeFinder(int v, MinHeap<Airport> minHeap) {
		this.minHeap = minHeap;
		this.v = v;
		upTree = new UpTree(v);
		list = new ArrayList<Airport>(v);		
	}

}
