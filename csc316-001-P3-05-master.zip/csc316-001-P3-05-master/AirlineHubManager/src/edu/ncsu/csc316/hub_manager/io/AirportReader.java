/**
 * 
 */
package edu.ncsu.csc316.hub_manager.io;


/**
 * Reads input from Airport input file.
 * @author Amiya Renavikar
 */
public class AirportReader {

	/** Stores the pathname to the Airport input file. */
	private String pathToAirportFile; 
	
	/**
	 * Constructs a Airport reader object.
	 * @param pathToAirportFile pathname to the Airport input file
	 */
	public AirportReader(String pathToAirportFile) {
		setPathToAirportFile(pathToAirportFile);
	}
	
	/**
	 * Sets the path to the Airport file.
	 * @param pathToAirportFile path to Airport file
	 */
	private void setPathToAirportFile(String pathToAirportFile) {
		this.pathToAirportFile = pathToAirportFile;
	}
	
	/**
	 * Returns the path to the Airport file.
	 * @return the pathToAirportFile path to Airport file.
	 */
	public String getPathToAirportFile() {
		return pathToAirportFile;
	}

	
	/**
	 * Reads in the input from the Airport input file and stores it in the AdjacencyList.
	 * @return a the AdjacencyList to be returned
	 * @throws FileNotFoundException if the correct file was not found
	 */
	/*public AdjacencyList readAirports() throws FileNotFoundException {
		BufferedReader bufferRead = null;
		AdjacencyList a = new AdjacencyList();
		String read = "";
		Scanner sc = null;
		bufferRead = new BufferedReader(new FileReader(new File(pathToAirportFile)));
		try {
			while(bufferRead.ready()) {
				read = bufferRead.readLine();
				sc = new Scanner(read);
				String code = sc.next();
				double latitude = sc.nextDouble();
				double longitude = sc.nextDouble();
				//create airport object 
				Airport airport = new Airport(code, latitude, longitude);
				a.add(airport);
				sc.close();
			}
			bufferRead.close();
		} catch (IOException e) {
			e.getMessage();
		}
		
		return a;
	}*/
	
}
