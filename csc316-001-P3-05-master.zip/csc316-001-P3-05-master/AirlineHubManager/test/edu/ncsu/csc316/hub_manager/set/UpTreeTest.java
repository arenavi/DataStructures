/**
 * 
 */
package edu.ncsu.csc316.hub_manager.set;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the UpTree class.
 * @author Amiya Renavikar
 */
public class UpTreeTest {

	/**
	 * Tests the UpTree class constructor.
	 */
	@Test
	public void testUpTree() {
		UpTree up = new UpTree(0);
		assertNotNull(up);
	}

}
