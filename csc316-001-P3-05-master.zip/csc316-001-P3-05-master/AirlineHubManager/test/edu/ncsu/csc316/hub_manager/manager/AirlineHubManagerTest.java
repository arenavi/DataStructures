/**
 * 
 */
package edu.ncsu.csc316.hub_manager.manager;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the AirlineHubManager class.
 * @author Amiya Renavikar
 */
public class AirlineHubManagerTest {

	/**
	 * Tests the AirlineHubManager class.
	 */
	@Test
	public void test() {
		AirlineHubManager ah = new AirlineHubManager("/input/airline.txt");
		assertNotNull(ah);
		assertEquals(null, ah.getMinimumFlights());
		assertEquals(null, ah.getPossibleHubs());
		assertNotNull(ah);
	}

}
