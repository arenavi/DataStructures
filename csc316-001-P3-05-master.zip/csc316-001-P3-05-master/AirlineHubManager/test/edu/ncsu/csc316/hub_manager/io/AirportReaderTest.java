/**
 * 
 */
package edu.ncsu.csc316.hub_manager.io;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;

/**
 * Tests the AirportReaderTest class.
 * @author Amiya Renavikar
 */
public class AirportReaderTest {

	/**
	 * Tests the AirportReader class.
	 * @throws FileNotFoundException 
	 */
	@Test
	public void testAirportReader() throws FileNotFoundException {
		AirportReader apr = new AirportReader("/input/airline.txt");
		assertNotNull(apr);
		assertEquals("/input/airline.txt", apr.getPathToAirportFile());
		
	}

}
