/**
 * 
 */
package edu.ncsu.csc316.hub_manager.graph;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the AdjacencyList class.
 * @author Amiya Renavikar
 */
public class AdjacencyListTest {

	/**
	 * Tests the AdjacencyList class.
	 */
	@Test
	public void test() {
		AdjacencyList al = new AdjacencyList();
		assertNotNull(al);
	}
}
