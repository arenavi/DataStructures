/**
 * 
 */
package edu.ncsu.csc316.hub_manager.queue;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the MinHeap class.
 * @author Amiya Renavikar
 */
public class MinHeapTest {

	/**
	 * Tests the minHeap constructor.
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void test() {
		MinHeap mh = new MinHeap();
		assertNotNull(mh);
	}

}
