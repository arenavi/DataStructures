/**
 * 
 */
package edu.ncsu.csc316.hub_manager.util;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc316.hub_manager.flight.Airport;
import edu.ncsu.csc316.hub_manager.queue.MinHeap;

/**
 * Tests the MinimumSpanningTreeFinder class.
 * @author Amiya Renavikar
 */
public class MinimumSpanningTreeFinderTest {

	/**
	 * Tests the constructor.
	 */
	@Test
	public void test() {
		MinHeap<Airport> mh = new MinHeap<Airport>();
		MinimumSpanningTreeFinder m = new MinimumSpanningTreeFinder(1, mh);
		assertNotNull(m);
	}

}
