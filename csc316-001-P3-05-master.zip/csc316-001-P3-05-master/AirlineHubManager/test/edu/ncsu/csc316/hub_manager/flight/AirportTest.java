/**
 * 
 */
package edu.ncsu.csc316.hub_manager.flight;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the Airport class. Based on the tests I wrote for Project 1 in CSC 316.
 * @author Amiya Renavikar
 */
public class AirportTest {

	/**
	 * Tests the Airport class constructor.
	 */
	@Test
	public void test() {
		Airport a = new Airport("DFW", 32.89680099487305, -97.03800201416016);
		assertNotNull(a);
	}
	
	/**
	 * Tests the getCode() method.
	 */
	@Test
	public void testGetCode() {
		Airport a = new Airport("DFW", 32.89680099487305, -97.03800201416016);
		assertEquals("DFW", a.getCode());
	}

	/**
	 * Tests the getLatitude() method.
	 */
	@Test
	public void testGetLatitude() {
		Airport a = new Airport("DFW", 32.89680099487305, -97.03800201416016);
		assertEquals(32.89680099487305, a.getLatitude(), 14);
	}
	
	/**
	 * Tests the getLongitude() method.
	 */
	@Test
	public void testGetLongitude() {
		Airport a = new Airport("DFW", 32.89680099487305, -97.03800201416016);
		assertEquals(-97.03800201416016, a.getLongitude(), 14);
	}
}
