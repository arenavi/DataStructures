package edu.ncsu.csc316.airline_mileage.ui;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import edu.ncsu.csc316.airline_mileage.manager.AirlineMileageManager;

/**
 * This class acts as the User Interface for the Airline Mileage Manager project.
 * Copied code from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class AirlineMileageUI {
	/**
	 * This is the main method of the AirlineMileageUI class.
	 * This method was implemented using parts of code from my projects 
	 * for CSC 116 and CSC 216.
	 * @param args command line argument.
	 * @throws FileNotFoundException if file is not found
	 */
	public static void main(String[] args) throws FileNotFoundException {
		//Import scanner
		Scanner sc = new Scanner(System.in);
		File airlineFile = new File("");
		File customerFile = new File("");
		File flightFile = new File("");
		//Enter file names while airline, customer, and flight files are null
		while (airlineFile == null) {
			System.out.print("Enter Airline file name: ");	
			airlineFile = new File(sc.next());
			//If file does not exist, set airline file to null and print message for re-prompt
			if (!airlineFile.exists()) {
				airlineFile = null;
				System.out.println("File does not exist!");
			}
		}
		while (customerFile == null) {
			System.out.print("Enter Customer file name: ");
			customerFile = new File(sc.next());
			if (!customerFile.exists()) {
				customerFile = null;
				System.out.println("File does not exist!");
			}
		}
		while (flightFile == null) {
			System.out.print("Enter Flight file name: ");
			flightFile = new File(sc.next());
			if (!flightFile.exists()) {
				flightFile = null;
				System.out.println("File does not exist!");
			}
		}
		//Create manager object
		AirlineMileageManager amm = new AirlineMileageManager(airlineFile.getAbsolutePath(), customerFile.getAbsolutePath(), 
				                                              flightFile.getAbsolutePath());
		
		int flag = 0;
		while (flag == 0) {
			System.out.print("Please enter what action you wish to perform (to get miles - enter m, to get mileage report - enter r, to quit - enter q)");
			String command = sc.next();
			if (command.equalsIgnoreCase("m")) {
				System.out.print("Enter first name of cardholder: ");
				String firstName = sc.next();
				System.out.print("Enter last name of cardholder: ");
				String lastName = sc.next();
				System.out.println(amm.getMiles(firstName, lastName));
			} else if (command.equalsIgnoreCase("r")) {
				System.out.println(amm.getMileageReport());
			} else if (command.equalsIgnoreCase("q")) {
				System.exit(0);
				flag = 1;
			} else {
				System.out.println("Command not found, please try again!");
			}
		}
		sc.close();
	}

}
