/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.dictionary;

import java.util.Arrays;

/**
 * This class is based on the implementation of ArrayList class from CSC 216.
 * Code used from CSC 316 Project 1 with minor edits and addition of an add method.
 * @author Amiya Renavikar
 * @param <E> generic type
 */
public class ArrayBasedList<E> {
	
	/** Default size of the arraylist */
	private static final int INIT_SIZE = 100;
	/** List containing customer objects */
	private E[] list;
	/** Size of the arraylist */
	private int size;
	
	/**
	 * Creates a sorted array list with a capacity of 100 objects.
	 */
	@SuppressWarnings("unchecked")
	public ArrayBasedList() {
		list = (E[]) new Object[INIT_SIZE];
		size = 0;
	}

	/**
	 * Creates a sorted array list with a capacity of 100 objects.
	 * @param size index to add.
	 */
	@SuppressWarnings("unchecked")
	public ArrayBasedList(int size) {
		list = (E[]) new Object[size];
		size = 0;
	}
	
	/**
	 * Returns number of objects in ArrayList
	 * @return the number
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Returns the element at the passed-in parameter index.
	 * @param idx index of the element
	 * @return object at the specified index.
	 */
	public E get(int idx) {
		if (idx < 0 || idx > size - 1) {
			throw new IndexOutOfBoundsException();
		}
		return list[idx];
	}
	
	/**
	 * Doubles the size of the array
	 */
	void growArray() {
		int newCap = list.length * 2 + 1;
		list = Arrays.copyOf(list, newCap);
	}

	/**
	 * Adds a customer object.
	 * @param object the object to be added
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 * @throws NullPointerException if object is null
	 * @throws IllegalArgumentException if object is duplicate
	 */
	public void add(E object) {
		if (object == null) {
			throw new NullPointerException();
		}
//		if (idx > size || idx < 0) {
//			throw new IndexOutOfBoundsException();
//		}
		if (list.length == size) {
			growArray();
		}
		list[size] = object;
		size++;
	}
	
	/**
	 * Adds a customer object at specified index.
	 * @param idx index at which object should be inserted
	 * @param obj the object to be added
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 */
	public void add(int idx, E obj) {
		if (idx > size || idx < 0) {
			throw new IndexOutOfBoundsException();
		}
		if (size == 0) {
			size++;
			list[idx] = obj;
			return;
		}
		if (size >= list.length - 1) {
			growArray();
		}
		for (int i = size; i > idx; i--) {
			list[i] = list[i - 1];
		}
		size++;
		list[idx] = obj;
	}
	
	/**
	 * Sets the element at index idx to Object object
	 * @param idx index to be set
	 * @param object object to be set
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 * @throws NullPointerException if object is null
	 * @throws IllegalArgumentException if object is duplicate
	 */
	public void set(int idx, E object) {
		if (object == null) {
			throw new NullPointerException();
		}
		if (idx > size || idx < 0) {
			throw new IndexOutOfBoundsException();
		}
//		if (idx == 0 && size == 0) {
//			throw new IndexOutOfBoundsException();
//		}
//		
		list[idx] = object;		
	}	

}

