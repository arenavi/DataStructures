package edu.ncsu.csc316.airline_mileage.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

import edu.ncsu.csc316.airline_mileage.data.Customer;
import edu.ncsu.csc316.airline_mileage.dictionary.ArrayBasedList;


/**
 * Reads input from Customer input file.
 * Used code from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class CustomerReader {
	
	/** Stores the pathname to the customer input file. */
	private String pathToCustomerFile; 
	
	/**
	 * Constructs a customer reader object.
	 * @param pathToCustomerFile pathname to the customer input file
	 */
	public CustomerReader(String pathToCustomerFile) {
		setPathToCustomerFile(pathToCustomerFile);
	}
	
	/**
	 * Sets the path to the customer file.
	 * @param pathToCustomerFile path to customer file
	 */
	private void setPathToCustomerFile(String pathToCustomerFile) {
		this.pathToCustomerFile = pathToCustomerFile;
	}
	
	/**
	 * Returns the path to the customer file.
	 * @return the pathToCustomerFile path to customer file.
	 */
	public String getPathToCustomerFile() {
		return pathToCustomerFile;
	}

	/**
	 * Reads a customer in from customer input file.
	 * @param pathToCustomerFile path to customer file
	 * @return customers arraylist of customers
	 * @throws FileNotFoundException if file is not found
	 */
	public static ArrayBasedList<Customer> readCustomer(String pathToCustomerFile) throws FileNotFoundException {
		File file = new File(pathToCustomerFile);
		Scanner sc = new Scanner(file);
		//Create arraylist for Airline
		ArrayBasedList<Customer> customers = new ArrayBasedList<Customer>();
		sc.nextLine();

		while (sc.hasNextLine()) {
				String newLine = sc.nextLine();
				Scanner lineNum = new Scanner(newLine);
			    //Use delimiter
				lineNum.useDelimiter(",");
				try {
					String firstName = lineNum.next();
					String lastName = lineNum.next();
					String dateOfTravel = lineNum.next();
					String flightNum = lineNum.next();
					String origin = lineNum.next();
					String dest = lineNum.next();
					customers.add(new Customer(firstName, lastName, dateOfTravel, flightNum, origin, dest));
				} catch (InputMismatchException e) {
					lineNum.close();
				}
				
		}
		sc.close();		
		return customers;
	}
}