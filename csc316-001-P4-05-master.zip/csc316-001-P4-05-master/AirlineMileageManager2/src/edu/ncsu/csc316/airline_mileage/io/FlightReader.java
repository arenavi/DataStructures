package edu.ncsu.csc316.airline_mileage.io;

import java.io.File;


import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;
import edu.ncsu.csc316.airline_mileage.data.Flight;
import edu.ncsu.csc316.airline_mileage.dictionary.ArrayBasedList;

/**
 * Reads input from Flight input file.
 * Used code from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class FlightReader {
	
	/** Stores the pathname to the flight input file. */
	private String pathToFlightFile;
	
	/**
	 * Constructs a FLightReader object.
	 * @param pathToFlightFile pathname to the flight input file
	 */
	public FlightReader(String pathToFlightFile) {
		setPathToFlightFile(pathToFlightFile);
	}

	/**
	 * Returns the path to the flight file.
	 * @return the pathToFlightFile path to flight file
	 */
	public String getPathToFlightFile() {
		return pathToFlightFile;
	}

	/**
	 * Sets the path to the flight file.
	 * @param pathToFlightFile path to flight file
	 */
	public void setPathToFlightFile(String pathToFlightFile) {
		this.pathToFlightFile = pathToFlightFile;
	}

	/**
	 * Reads the input Flight file and returns an arraylist containing flight objects.
	 * @param pathToFlightFile path to flight input file
	 * @return flights Arraylist containing flight objects
	 * @throws FileNotFoundException if file is not found
	 */
	public static ArrayBasedList<Flight> readFlight(String pathToFlightFile) throws FileNotFoundException {
		File file = new File(pathToFlightFile);
		Scanner sc = new Scanner(file);
		//Create arraylist for Flight
		//Create arraylist for Airline
		ArrayBasedList<Flight> flights = new ArrayBasedList<Flight>();
	
		while (sc.hasNextLine()) {
			String newLine = sc.nextLine();
			Scanner lineNum = new Scanner(newLine);
			//Use delimiter
			lineNum.useDelimiter(",");
			try {
				String year = lineNum.next();
				String month = lineNum.next();
				String day = lineNum.next();
				String dayOfWeek = lineNum.next();
				String airline = lineNum.next();
				String flightNumber = lineNum.next();
				String originAirport = lineNum.next();
				String destinationAirport = lineNum.next();
				String scheduledDeparture = lineNum.next();
				String departureTime = lineNum.next();
				String distance = lineNum.next();
				String scheduledArrival = lineNum.next();
				String arrivalDelay = lineNum.next();
				flights.add(new Flight(year, month, day, dayOfWeek, airline, flightNumber, originAirport,
						               destinationAirport, scheduledDeparture, departureTime, distance,
						               scheduledArrival, arrivalDelay));
			} catch (InputMismatchException e) {
				lineNum.close();
			}
		}
			sc.close();		
			return flights;
	}

}