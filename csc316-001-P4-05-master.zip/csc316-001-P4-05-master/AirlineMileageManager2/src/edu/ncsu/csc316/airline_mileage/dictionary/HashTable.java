/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.dictionary;

/**
 * Creates the HashTable data structure.
 * @author Amiya Renavikar
 * @param <E> generic type 
 */
public class HashTable<E> {
	
	/** An ArrayBasedList that creates a hashtable */
	private ArrayBasedList<Bucket<E>> hashTable;
	/** Size of table */
	private int size;
	
	
	/**
	 * Constructs a HashTable object.
	 */
	public HashTable() {
		size = 0;
		hashTable = new ArrayBasedList<Bucket<E>>(51109 + 1);
		for (int i = 0; i < 51109 + 1; i++) {
			hashTable.add(i, null);
		}
	}
	
	/**
	 * Returns the hash value.
	 * @param next the value to create a hash value
	 * @return hashValue hash code
	 */
	private int hashFunct(E next) {
		int hashValue = 0;
		String s = (String) next;
		double invphi = 0.61803398875;
		for (int i = 0; i < s.length(); i++) {
			hashValue = (int) (hashValue + s.charAt(i) * (Math.pow(41, s.length() - i - 1)));
		}
		double temp = (hashValue * invphi) - Math.floor(hashValue * invphi);
		hashValue = (int) Math.floor(temp * 51109);
		return hashValue;
	}
	
	/**
	 * Returns true if the value is found in the HAshTable, false otherwise.
	 * @param next the value to create a hash value- search value
	 * @return false is the value is not found
	 */
	public boolean lookUp(E next) {
		int index = hashFunct(next);
		int count = 0;
		int inc = 5 + (index % 41);
		do {
			if (hashTable.get(index) == null) {
				return false;
			} else if (hashTable.get(index).next.equals(next)) {
				return true;
			} else {
				index += inc;
				if (index > 51109) {
					index = index % 51109;
				}
			}
			count++;
		} while (count < 51109);
		return false;
	}
	
	/**
	 * Inserts the specified value into the hash table.
	 * @param next the value to be inserted
	 */
	public void insert(E next) {
		int index = hashFunct(next);
		int count = 0;
		int inc = 5 + (index % 41);
		boolean neg = true;
		do {
			if (hashTable.get(index) == null) {
				Bucket<E> temp = new Bucket<E>(next);
				hashTable.set(index, temp);
				neg = false;
				this.size++;
			} else {
				index += inc;
				if (index > 51109) {
					index = index % 51109;
				}
			}
			count++;
		} while (neg && count < 51109);
	}

	/**
	 * Returns the size of the hash table.
	 * @return size the size of the hash table
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Inner class to store buckets.
	 * @author Amiya Renavikar
	 *
	 * @param <E> generic type
	 */
	@SuppressWarnings("hiding")
	public class Bucket<E> {
		
		/** Object stored in the next node */
		private E next;
		
		/**
		 * Constructs a Bucket object.
		 * @param next object stored in the next node
		 */
		public Bucket(E next) {
			this.next = next;
		}
	}

}
