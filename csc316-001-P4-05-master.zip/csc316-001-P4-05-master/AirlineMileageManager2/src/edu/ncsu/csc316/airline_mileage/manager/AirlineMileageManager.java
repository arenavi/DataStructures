/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.manager;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.util.Scanner;

import edu.ncsu.csc316.airline_mileage.data.Airline;
import edu.ncsu.csc316.airline_mileage.data.Customer;
import edu.ncsu.csc316.airline_mileage.data.Flight;
import edu.ncsu.csc316.airline_mileage.dictionary.ArrayBasedList;
import edu.ncsu.csc316.airline_mileage.dictionary.HashTable;
/**
 * Maintains the functionality of the AirlineMileageManager program.
 * Used some code from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class AirlineMileageManager {
	
	/** Arraylist holding airline input. */
	private ArrayBasedList<Airline> airlineList;
	/** Arraylist holding customer input. */
	private ArrayBasedList<Customer> customerList;
	/** Arraylist holding flight input. */
	private ArrayBasedList<Flight> flightList;
	/** Data structure used to build a hash table */
	@SuppressWarnings("unused")
	private HashTable<String> hash;
	/**
	 * Constructs an AirlineMileageManager.
	 * 
	 * @param pathToAirlineFile - path to the airline information file
	 * @param pathToCustomerFile - path to the customer information file
	 * @param pathToFlightFile - path to the flight information file
	 */
	public AirlineMileageManager(String pathToAirlineFile, String pathToCustomerFile, String pathToFlightFile) {
		//pathToAirlineFile = "input/airline";
//		AirlineReader a = new AirlineReader(pathToAirlineFile);
//		try {
//			airlineList = a.readAirline(pathToAirlineFile);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		//pathToCustomerFile = "input/customer";
//		CustomerReader c = new CustomerReader(pathToCustomerFile);
//		try {
//			customerList = c.readCustomer(pathToCustomerFile);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		//pathToFlightFile = "input/flight";
//		FlightReader f = new FlightReader(pathToFlightFile);
//		try {
//			flightList = f.readFlight(pathToFlightFile);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		airlineList = new ArrayBasedList<Airline>();
		customerList = new ArrayBasedList<Customer>();
		flightList = new ArrayBasedList<Flight>();
		hash = new HashTable<String>();
		try(Scanner in = new Scanner(new FileInputStream(pathToAirlineFile))) {
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try(Scanner in = new Scanner(new FileInputStream(pathToCustomerFile))) {
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try(Scanner in = new Scanner(new FileInputStream(pathToCustomerFile))) {
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Produces the mileage report for all cardholders
	 * as a String, sorted alphabetically by cardholder
	 * last name.
	 * 
	 * @return the mileage report for all customers
	 */
	public String getMileageReport()
	{
		String mileageReport = "";
		Customer c1 = new Customer("", "", "", "", "", "");
		customerList.add(c1);
			for (int i = 0; i <= customerList.size() - 1; i++) {
				mileageReport += customerList.get(i).getFirstName() + 
					         customerList.get(i).getLastName() + 
					         " earned" + '\n';
			}

		Flight f1 = new Flight("", "", "", "", "", "", "", "", "", "", "", "", "");
		flightList.add(f1);
			for (int j = 0; j <= flightList.size() - 1; j++) {
				mileageReport += flightList.get(j).getDistance() + " miles with ";  
			}

		Airline a1 = new Airline("", "", "", "");
		airlineList.add(a1);
			for (int k = 0; k <= airlineList.size() - 1; k++) {
				mileageReport += airlineList.get(k).getDescription() + " (" + 
					         airlineList.get(k).getIataCode() + ")";				         
			}
		return mileageReport;
	}
	
	/**
	 * Retrieves the frequent flier mileage for the specified
	 * cardholder with the given first name and last name.
	 * Miles are listed in descending order by distance
	 * 
	 * @param firstName - the cardholder's first name
	 * @param lastName - the cardholder's last name
	 * @return the frequent flier mileage information for the cardholder
	 */
	public String getMiles(String firstName, String lastName) {
		Customer c1 = new Customer("" , "", "", "", "", "");
		customerList.add(c1);
		Flight f1 = new Flight("", "", "", "", "", "", "", "", "", "", "", "", "");
		flightList.add(f1);
		for (int i = 1; i < customerList.size() - 1; i++) {
			if(customerList.get(i).getFirstName().equals(firstName) &&
			   customerList.get(i).getLastName().equals(lastName)) {
				return flightList.get(i).getDistance();
				
			}
		}
	    return "The user has earned no miles!";
	}
}