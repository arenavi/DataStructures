package edu.ncsu.csc316.airline_mileage.io;

import java.io.File;


import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

import edu.ncsu.csc316.airline_mileage.data.Airline;
import edu.ncsu.csc316.airline_mileage.dictionary.ArrayBasedList;

/**
 * Reads the airline input file.
 * Used code and ideas from CSC 316 Project 1.
 * @author Amiya Renavikar 
 */
public class AirlineReader {
	
	/** Stores the pathname to the airline input file. */
	private String pathToAirlineFile;
	
	/**
	 * Constructs an airline reader object.
	 * @param pathToAirlineFile pathname to the airline input file
	 */
	public AirlineReader(String pathToAirlineFile) {
		setPathToAirlineFile(pathToAirlineFile);
	}

	/**
	 * Sets the path to the airline file.
	 * @param pathToAirlineFile path to airline file
	 */
	private void setPathToAirlineFile(String pathToAirlineFile) {
		this.pathToAirlineFile = pathToAirlineFile;
	}
	
	/**
	 * Returns the path to the airline file.
	 * @return pathToAirlineFile path to the airline input file
	 */
	public String getPathToAirlineFile() {
		return pathToAirlineFile;
	}

	/**
	 * Reads the input Airline file and returns an arraylist containing airline objects.
	 * @param pathToAirlineFile path to airline input file
	 * @return airlines ArrayBasedlist containing airline objects
	 * @throws FileNotFoundException when file is not found
	 */
	public static ArrayBasedList<Airline> readAirline(String pathToAirlineFile) throws FileNotFoundException {
		File file = new File(pathToAirlineFile);
		Scanner sc = new Scanner(file);
		//Create arraylist for Airline
		ArrayBasedList<Airline> airlines = new ArrayBasedList<Airline>();
		sc.nextLine();

		while (sc.hasNextLine()) {
				String newLine = sc.nextLine();
				Scanner lineNum = new Scanner(newLine);
			    //Use delimiter
				lineNum.useDelimiter(",");
				try {
					String description = lineNum.next();
					String iataCode = lineNum.next();
					String callSign = lineNum.next();
					String country = lineNum.next();
					Airline a = new Airline(description, iataCode, callSign, country);
					airlines.add(a);
				} catch (InputMismatchException e) {
					lineNum.close();
				}
				
		}
		sc.close();		
		return airlines;
	}
}

