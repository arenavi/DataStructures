package edu.ncsu.csc316.airline_manager.data;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.data.Customer;

/**
 * Tests the Customer class.
 * Used code and ideas from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class CustomerTest {

	/**
	 * Tests the Customer class methods.
	 */
	@Test
	public void test() {
		Customer c = new Customer("Erick", "Mcfarland", "12/20/2015", "UA346", "ORD", "MIA");
		assertEquals("Erick", c.getFirstName());
		assertEquals("Mcfarland", c.getLastName());
		assertEquals("UA", c.getFlightNumName());
	}

}
