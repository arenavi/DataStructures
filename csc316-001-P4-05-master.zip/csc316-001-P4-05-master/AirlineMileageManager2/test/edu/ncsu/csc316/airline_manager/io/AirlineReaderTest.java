/**
 * 
 */
package edu.ncsu.csc316.airline_manager.io;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.data.Airline;
import edu.ncsu.csc316.airline_mileage.dictionary.ArrayBasedList;
import edu.ncsu.csc316.airline_mileage.io.AirlineReader;

/**
 * Tests the AirlineReaderTest class.
 * Used code and ideas from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class AirlineReaderTest {

	/**
	 * Tests the AirlineReader class methods.
	 */
	@Test
	public void test() {
		AirlineReader ar = null;
		assertEquals(null, ar);
		ar = new AirlineReader("input/airline");
		assertEquals("input/airline", ar.getPathToAirlineFile());
		try {
			@SuppressWarnings("static-access")
			ArrayBasedList<Airline> aa = ar.readAirline("input/airline");
			assertEquals("United Airlines", aa.get(0).getDescription());
			assertEquals("UA", aa.get(0).getIataCode());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block

		}
	}

}
