/**
 * 
 */
package edu.ncsu.csc316.airline_manager.io;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.data.Customer;
import edu.ncsu.csc316.airline_mileage.dictionary.ArrayBasedList;
import edu.ncsu.csc316.airline_mileage.io.CustomerReader;

/**
 * Tests the CustomerReaderTest class.
 * Used code from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class CustomerReaderTest {

	/**
	 * Tests the CustomerReader class methods.
	 */
	@Test
	public void test() {
		CustomerReader ar = null;
		assertEquals(null, ar);
		ar = new CustomerReader("input/customer");
		assertEquals("input/customer", ar.getPathToCustomerFile());
		try {
			@SuppressWarnings("static-access")
			ArrayBasedList<Customer> cc = ar.readCustomer("input/customer");
			assertEquals("Erick", cc.get(0).getFirstName());
			assertEquals("Mcfarland", cc.get(0).getLastName());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block

		}
	}

}
