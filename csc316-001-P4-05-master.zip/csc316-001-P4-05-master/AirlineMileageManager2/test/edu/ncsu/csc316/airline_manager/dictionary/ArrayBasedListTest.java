package edu.ncsu.csc316.airline_manager.dictionary;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.dictionary.ArrayBasedList;

/**
 * Tests the ArrayList class and is based on the implementation I wrote for
 * Project 3 in CSC 216. Code is from Project 1 CSC 316.
 * @author Amiya Renavikar
 */
public class ArrayBasedListTest {

	/**
	 * Tests the ArrayList class methods.
	 */
	@Test
	public void testArrayList() {
		//Check for null list
		ArrayBasedList<Object> a = null;
		try {
			a = new ArrayBasedList<Object>();
		} catch (IllegalArgumentException e) {
			//do nothing
		}
		//Check if size is 0
		a = new ArrayBasedList<Object>();
		assertEquals(0, a.size());
		//Add object and check get() method
		a.add("Name");
		assertEquals("Name", a.get(0));
		//check for below 0 index get
		try {
			a.get(-1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, a.size());
		}
		//check for size -1 index
		try {
			a.get(4);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, a.size());
		}
		//now check for set
		a.set(0, "Random");
		assertEquals(1, a.size());
		//try adding null object
		try {
			a.add(null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(1, a.size());
		}
		//check idx < 0
		try {
			a.set(-1, "Hey");
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, a.size());
		}
		//check idx > size
		try {
			a.set(3, "Hey");
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, a.size());
		}
		//try setting null object
		try {
			a.set(0, null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(1, a.size());
		}
		a.add("Hola");
		a.add("Bonjour");
		a.add("Hi");
	    assertEquals(4, a.size());

	}

}
