package edu.ncsu.csc316.airline_manager.data;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.data.Flight;

/**
 * Tests the Flight class.
 * Used code and ideas from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class FlightTest {

	/**
	 * Tests the Flight class methods.
	 */
	@Test
	public void test() {
		Flight f = new Flight("2015", "12", "20", "7", "UA", "346", "ORD", "MIA", "0730", "0730", "1197", "1139", "-20");
		assertEquals("1197", f.getDistance());
	}

}
