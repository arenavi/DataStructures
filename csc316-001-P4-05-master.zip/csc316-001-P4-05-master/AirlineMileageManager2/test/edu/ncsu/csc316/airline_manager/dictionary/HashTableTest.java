/**
 * 
 */
package edu.ncsu.csc316.airline_manager.dictionary;

import static org.junit.Assert.*;


import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.dictionary.HashTable;

/**
 * Tests the HashTable class.
 * @author Amiya Renavikar
 */
public class HashTableTest {

	/**
	 * Tests the HashTable class methods.
	 */
	@Test
	public void test() {
		HashTable<String> ht = new HashTable<String>();
		ht.insert("Hello");
		ht.insert("My name is John");
		ht.insert("My name is John");
		ht.insert("Noway");
		assertTrue(ht.lookUp("Hello"));
		assertTrue(ht.lookUp("My name is John"));
		assertTrue(ht.lookUp("Noway"));
		assertFalse(ht.lookUp("HI"));
		assertEquals(4, ht.size());
		
	}

}
