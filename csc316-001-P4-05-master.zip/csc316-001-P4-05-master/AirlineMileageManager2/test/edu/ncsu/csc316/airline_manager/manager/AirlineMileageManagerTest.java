/**
 * 
 */
package edu.ncsu.csc316.airline_manager.manager;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.manager.AirlineMileageManager;

/**
 * Tests the AirlineMileageManager class.
 * Use of previous code from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class AirlineMileageManagerTest {

	/**
	 * Tests the AirlineMileageManager constructor.
	 */
	@Test
	public void testAirlineMileageManager() {
		AirlineMileageManager a = null;
		assertEquals(null, a);
	    a = new AirlineMileageManager("input/airline", "input/customer", "input/flight");
	    assertNotEquals(null, a);
	}
	
	/**
	 * Tests the getMileageReport() method.
	 */
	@SuppressWarnings("unused")
	@Test
	public void testGetMileageReport() {
		AirlineMileageManager a = new AirlineMileageManager("input/airline", "input/customer", "input/flight");
		String s = a.getMileageReport();
		assertNotEquals(null, a);	
	}
	
	/**
	 * Tests the getMiles() method.
	 */
	@Test
	public void testGetMiles() {
		AirlineMileageManager a = new AirlineMileageManager("input/airline", "input/customer", "input/flight");
		String b = null;
		assertEquals(null, b);
		b = a.getMiles("Erick", "Mcfarland");
		assertNotEquals(null, b);
		String c = a.getMiles("Kassandra", "Stiltner");
		assertNotEquals(null, c);
		System.out.println(c);
	}

}
