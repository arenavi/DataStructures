/**
 * 
 */
package edu.ncsu.csc316.airline_manager.io;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.data.Flight;
import edu.ncsu.csc316.airline_mileage.dictionary.ArrayBasedList;
import edu.ncsu.csc316.airline_mileage.io.FlightReader;

/**
 * Tests the FlightReaderTest class.
 * Used code from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class FlightReaderTest {

	/**
	 * Tests the FlightReader class methods.
	 */
	@Test
	public void test() {
		FlightReader ar = null;
		assertEquals(null, ar);
		ar = new FlightReader("input/flight");
		assertEquals("input/flight", ar.getPathToFlightFile());
		try {
			@SuppressWarnings("static-access")
			ArrayBasedList<Flight> aa = ar.readFlight("input/flight");
			assertEquals("DISTANCE", aa.get(0).getDistance());
			assertEquals("1197", aa.get(1).getDistance());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block

		}
	}

}
