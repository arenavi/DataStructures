package edu.ncsu.csc316.airline_manager.data;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.data.Airline;

/**
 * Tests the Airline class.
 * Used ideas and code from CSC 316 Project 1.
 * @author Amiya Renavikar
 */
public class AirlineTest {

	/**
	 * Tests the Airline class methods.
	 */
	@Test
	public void test() {
		Airline a = new Airline("United Airlines", "UA", "UNITED", "United States");
		assertEquals("United Airlines", a.getDescription());
		assertEquals("UA", a.getIataCode());
	}

}
