/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.list;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the ArrayList class and is based on the implementation I wrote for
 * Project 3 in CSC 216.
 * @author Amiya Renavikar
 */
public class ArrayListTest {

	/**
	 * Tests the ArrayList class methods.
	 */
	@Test
	public void testArrayList() {
		//Check for null list
		ArrayList<Object> a = null;
		try {
			a = new ArrayList<Object>(10);
		} catch (IllegalArgumentException e) {
			assertNull(a);
		}
		//Check if size is 0
		a = new ArrayList<Object>(10);
		assertEquals(0, a.size());
		//Add object and check get() method
		a.add("Name");
		assertEquals("Name", a.get(0));
		//check for below 0 index get
		try {
			a.get(-1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, a.size());
		}
		//check for size -1 index
		try {
			a.get(4);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, a.size());
		}
		//now check for set
		a.set(0, "Random");
		assertEquals(1, a.size());
		//try adding null object
		try {
			a.add(null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(1, a.size());
		}
		//check idx < 0
		try {
			a.set(-1, "Hey");
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, a.size());
		}
		//check idx > size
		try {
			a.set(3, "Hey");
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(1, a.size());
		}
		//try setting null object
		try {
			a.set(0, null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(1, a.size());
		}
		a.add("Hola");
		a.add("Bonjour");
		a.add("Hi");
	    assertEquals(4, a.size());
		//test for grow array
		a.growArray();
		assertEquals(4, a.size());

	}

}
