/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.io;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.data.Airline;
import edu.ncsu.csc316.airline_mileage.list.ArrayList;

/**
 * Tests the AirlineReaderTest class.
 * @author Amiya Renavikar
 */
public class AirlineReaderTest {

	/**
	 * Tests the AirlineReader class.
	 */
	@Test
	public void testAirlineReader() {
		AirlineReader ar = null;
		assertNull(ar);
		ar = new AirlineReader("input/airline.txt");
		assertNotNull(ar);
		assertEquals("input/airline.txt", ar.getPathToAirlineFile());
		try {
			@SuppressWarnings("static-access")
			ArrayList<Airline> aa = ar.readAirline("input/airline.txt");
			assertEquals("DESCRIPTION", aa.get(0).getDescription());
			assertEquals("IATA_CODE", aa.get(0).getIataCode());
			assertEquals("United Airlines", aa.get(1).getDescription());
			assertEquals("UA", aa.get(1).getIataCode());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block

		}
		
	}

}
