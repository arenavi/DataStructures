/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.io;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;
import edu.ncsu.csc316.airline_mileage.data.Customer;
import edu.ncsu.csc316.airline_mileage.list.ArrayList;

/**
 * Tests the AirlineReaderTest class.
 * @author Amiya Renavikar
 */
public class CustomerReaderTest {

	/**
	 * Tests the AirlineReader class.
	 */
	@Test
	public void testCustomerReader() {
		CustomerReader ar = null;
		assertNull(ar);
		ar = new CustomerReader("input/customer.txt");
		assertNotNull(ar);
		assertEquals("input/customer.txt", ar.getPathToCustomerFile());
		try {
			@SuppressWarnings("static-access")
			ArrayList<Customer> cc = ar.readCustomer("input/customer.txt");
			assertEquals("FIRST", cc.get(0).getFirstName());
			assertEquals("LAST", cc.get(0).getLastName());
			assertEquals("Erick", cc.get(1).getFirstName());
			assertEquals("Mcfarland", cc.get(1).getLastName());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block

		}
		
	}

}
