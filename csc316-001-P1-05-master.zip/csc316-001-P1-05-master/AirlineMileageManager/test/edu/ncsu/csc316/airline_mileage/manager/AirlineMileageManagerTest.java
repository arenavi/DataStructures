/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.manager;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Tests the AirlineMileageManager class.
 * @author Amiya Renavikar
 */
public class AirlineMileageManagerTest {

	/**
	 * Tests the AirlineMileageManager constructor.
	 */
	@Test
	public void testAirlineMileageManager() {
		AirlineMileageManager a = null;
		assertNull(a);
	    a = new AirlineMileageManager("/input/airline.txt", "/input/customer.txt", "/input/flight.txt");
		assertNotNull(a);
	}
	
	/**
	 * Tests the getMileageReport() method.
	 */
	@Test
	public void testGetMileageReport() {
		AirlineMileageManager a = new AirlineMileageManager("/input/airline.txt", "/input/customer.txt",
				"/input/flight.txt");
		String s = a.getMileageReport();
		assertNotNull(s);	
	}
	
	/**
	 * Tests the getMiles() method.
	 */
	@Test
	public void testGetMiles() {
		AirlineMileageManager a = new AirlineMileageManager("/input/airline.txt", "/input/customer.txt", "/input/flight.txt");
		String b = a.getMiles("Erick", "Mcfarland");
		assertNotNull(b);
		String c = a.getMiles("Kassandra", "Stiltner");
		assertNotNull(c);
		System.out.println(c);
	}

}
