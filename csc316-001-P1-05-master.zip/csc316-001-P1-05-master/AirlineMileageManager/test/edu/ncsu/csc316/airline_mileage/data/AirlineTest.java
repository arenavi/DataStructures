/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.data;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the Airline class.
 * @author Amiya Renavikar
 */
public class AirlineTest {

	/**
	 * Tests the Airline class constructor.
	 */
	@Test
	public void testAirline() {
		Airline a = new Airline("United Airlines", "UA", "UNITED", "United States");
		assertNotNull(a);
	}
	
	/**
	 * Tests the getDescription() method.
	 */
	@Test
	public void testGetDescription() {
		Airline a = new Airline("United Airlines", "UA", "UNITED", "United States");
		assertEquals("United Airlines", a.getDescription());
	}
	
	/**
	 * Tests the getIataCode() method.
	 */
	@Test
	public void testGetIataCode() {
		Airline a = new Airline("United Airlines", "UA", "UNITED", "United States");
		assertEquals("UA", a.getIataCode());
	}
}
