/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.io;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;
import edu.ncsu.csc316.airline_mileage.data.Flight;
import edu.ncsu.csc316.airline_mileage.list.ArrayList;

/**
* Tests the FlightReaderTest class.
 * @author Amiya Renavikar
 */
public class FlightReaderTest {

	/**
	 * Tests the FlightReader class.
	 */
	@Test
	public void testFlightReader() {
		FlightReader ar = null;
		assertNull(ar);
		ar = new FlightReader("input/flight.txt");
		assertNotNull(ar);
		assertEquals("input/flight.txt", ar.getPathToFlightFile());
		try {
			@SuppressWarnings("static-access")
			ArrayList<Flight> aa = ar.readFlight("input/flight.txt");
			assertEquals("DISTANCE", aa.get(0).getDistance());
			assertEquals("1197", aa.get(1).getDistance());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block

		}
		
	}

}
