/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.list;
import static org.junit.Assert.*;

import org.junit.Test;

import edu.ncsu.csc316.airline_mileage.data.Customer;

/**
 * Tests the SortedCustomerArrayListTest class (based on CSC 216 implementation).
 * @author Amiya Renavikar
 */
public class SortedCustomerArrayListTest {

	/**
	 * Tests the SortedCustomerArrayList class constructor.
	 */
	@Test
	public void testSortedCustomerArrayList() {
		SortedCustomerArrayList s = null;
		try {
			s = new SortedCustomerArrayList();
		} catch (IllegalArgumentException e) {
			assertNull(s);
		}	
		s = new SortedCustomerArrayList();
		assertEquals(0, s.size());
	}
	
	/**
	 * Tests the get() method.
	 */
	@Test
	public void testGet() {
		SortedCustomerArrayList s = new SortedCustomerArrayList();
		//check for idx < 0
		try {
			s.get(-1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(0, s.size());
		}
		Customer c1 = new Customer("Kassandra", "Stiltner", "12/20/2015", "UA346", "ORD", "MIA");
		Customer c2 = new Customer("Erick", "Mcfarland", "1/27/2015", "B61316", "FLL" , "JAX");
		s.add(c1);
		s.add(c2);
		//check for idx > size - 1
		try {
			s.get(3);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(2, s.size());
		}
		assertEquals(c1, s.get(0));
		assertEquals(c2, s.get(1));
	}
	
	/**
	 * Tests the add method.
	 */
	@Test
	public void testAdd() {
		SortedCustomerArrayList s = new SortedCustomerArrayList();
		Customer c1 = new Customer("Kassandra", "Stiltner", "12/20/2015", "UA346", "ORD", "MIA");
		try {
			s.add(null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(0, s.size());
		}
		s.add(c1);
		assertEquals(1, s.size());
	}
	
	/**
	 * Tests the set() method.
	 */
	@Test
	public void testSet() {
		SortedCustomerArrayList s = new SortedCustomerArrayList();
		Customer c1 = new Customer("Kassandra", "Stiltner", "12/20/2015", "UA346", "ORD", "MIA");
		Customer c2 = new Customer("Erick", "Mcfarland", "1/27/2015", "B61316", "FLL" , "JAX");
		try {
			s.set(0, null);
			fail();
		} catch (NullPointerException e) {
			assertEquals(0, s.size());
		}
		//check idx > 0
		try {
			s.set(-1, c1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(0, s.size());
		}
		s.add(c1);
		s.add(c2);
		assertEquals(2, s.size());
		//check idx > size
		try {
			s.set(3, c1);
			fail();
		} catch (IndexOutOfBoundsException e) {
			assertEquals(2, s.size());
		}
		s.set(0, c2);
	}
	
	/**
	 * Tests the growArray() method.
	 */
	@Test
	public void testGrowArray() {
		SortedCustomerArrayList s = new SortedCustomerArrayList();
		Customer c1 = new Customer("Kassandra", "Stiltner", "12/20/2015", "UA346", "ORD", "MIA");
		s.add(c1);
		assertEquals(1, s.size());
		s.growArray();
		assertEquals(1, s.size());
	}
}
