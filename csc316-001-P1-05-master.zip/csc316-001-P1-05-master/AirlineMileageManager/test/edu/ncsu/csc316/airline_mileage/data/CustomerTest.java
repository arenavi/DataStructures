package edu.ncsu.csc316.airline_mileage.data;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * Tests the Customer class.
 * @author Amiya Renavikar
 */
public class CustomerTest {

	/**
	 * Tests the Customer class constructor.
	 */
	@Test
	public void testCustomer() {
		Customer c = new Customer("Erick", "Mcfarland", "12/20/2015", "UA346", "ORD", "MIA");
		assertNotNull(c);
	}
	
	/**
	 * Tests the getFirstName() method.
	 */
	@Test
	public void testGetFirstName() {
		Customer c = new Customer("Erick", "Mcfarland", "12/20/2015", "UA346", "ORD", "MIA");
		assertEquals("Erick", c.getFirstName());
	}
	
	/**
	 * Tests the getLastName() method.
	 */
	@Test
	public void testGetLastName() {
		Customer c = new Customer("Erick", "Mcfarland", "12/20/2015", "UA346", "ORD", "MIA");
		assertEquals("Mcfarland", c.getLastName());
	}
	
	/**
	 * Tests the getFlightNumName() method.
	 */
	@Test
	public void testGetFlightNumName() {
		Customer c = new Customer("Erick", "Mcfarland", "12/20/2015", "UA346", "ORD", "MIA");
		assertEquals("UA", c.getFlightNumName());
	}

}
