/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc316.airline_mileage.data.Customer;
import edu.ncsu.csc316.airline_mileage.list.ArrayList;

/**
 * Reads input from Customer input file.
 * @author Amiya Renavikar
 */
public class CustomerReader {
	
	/** Stores the pathname to the customer input file. */
	private String pathToCustomerFile; 
	
	/**
	 * Constructs a customer reader object.
	 * @param pathToCustomerFile pathname to the customer input file
	 */
	public CustomerReader(String pathToCustomerFile) {
		setPathToCustomerFile(pathToCustomerFile);
	}
	
	/**
	 * Sets the path to the customer file.
	 * @param pathToCustomerFile path to customer file
	 */
	private void setPathToCustomerFile(String pathToCustomerFile) {
		this.pathToCustomerFile = pathToCustomerFile;
	}

	/**
	 * Reads a customer in from customer input file.
	 * @param pathToCustomerFile path to customer file
	 * @return customers arraylist of customers
	 * @throws FileNotFoundException if file is not found
	 */
	public static ArrayList<Customer> readCustomer(String pathToCustomerFile) throws FileNotFoundException {
		File input = new File(pathToCustomerFile);

		if (!input.exists()) {
			throw new FileNotFoundException("Error finding file!");
		}
		//Create arraylist for Customer
		ArrayList<Customer> customers = new ArrayList<Customer>(100);
		//Try to read file
		try (Scanner file = new Scanner(input)) {
			while (file.hasNextLine()) {
				Scanner lineNum = new Scanner(file.nextLine());
			    //USe delimiter????
				lineNum.useDelimiter(",");
				String firstName = lineNum.next().trim();
				String lastName = lineNum.next().trim();
				String dateOfTravel = lineNum.next().trim();
				String flightNum = lineNum.next().trim();
				String origin = lineNum.next().trim();
				String dest = lineNum.next().trim();
				customers.add(new Customer(firstName, lastName, dateOfTravel, flightNum, origin, dest));
				lineNum.close();
			}
			file.close();
		} catch (NoSuchElementException e) {
			//do nothing
		}
		return customers;
	}

	/**
	 * Returns the path to the customer file.
	 * @return the pathToCustomerFile path to customer file.
	 */
	public String getPathToCustomerFile() {
		return pathToCustomerFile;
	}

}
