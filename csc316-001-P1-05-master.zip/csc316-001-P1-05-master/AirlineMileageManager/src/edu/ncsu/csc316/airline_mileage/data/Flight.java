package edu.ncsu.csc316.airline_mileage.data;

/**
 * Creates a flight object with year, month, day, day of the week, airline, flight number,
 * origin airport, destination airport, scheduled departure, departure time, distance,
 * scheduled arrival, and arrival delay.
 * @author Amiya Renavikar
 */
public class Flight {
	/** Year when the flight was arranged */
	@SuppressWarnings("unused")
	private String year;
	/** Month when the flight was arranged */
	@SuppressWarnings("unused")
	private String month;
	/** Day when the flight was arranged */
	@SuppressWarnings("unused")
	private String day;
	/** Day of the week when the flight was arranged */
	@SuppressWarnings("unused")
	private String dayOfWeek;
	/** Flight airline */
	@SuppressWarnings("unused")
	private String airline;
	/** Flight number */
	@SuppressWarnings("unused")
	private String flightNumber;
	/** Origin airport for the flight */
	@SuppressWarnings("unused")
	private String originAirport;
	/** Destination airport for the flight */
	@SuppressWarnings("unused")
	private String destinationAirport;
	/** Scheduled departure time for the flight */
	@SuppressWarnings("unused")
	private String scheduledDeparture;
	/** Actual departure time for the flight */
	@SuppressWarnings("unused")
	private String departureTime;
	/** Distance that the flight traveled */
	private String distance;
	/** Scheduled arrival time for the flight */
	@SuppressWarnings("unused")
	private String scheduledArrival;
	/** Arrival delay time for the flight */
	@SuppressWarnings("unused")
	private String arrivalDelay;
	
	/**
	 * Creates a flight object with given flight details.
	 * @param year year of the flight
	 * @param month month of the flight
	 * @param day date of the flight
	 * @param dayOfWeek day of the week the flight will be flown
	 * @param airline name of the flight's airline
	 * @param flightNumber flight number
	 * @param originAirport origin airport
	 * @param destinationAirport destination airport
	 * @param scheduledDeparture scheduled departure time
	 * @param departureTime actual departure time
	 * @param distance distance traveled by the flight
	 * @param scheduledArrival scheduled arrival time
	 * @param arrivalDelay duration of delay if flight is delayed
	 */
	public Flight (String year, String month, String day, String dayOfWeek, String airline, String flightNumber, String originAirport, 
			       String destinationAirport, String scheduledDeparture, String departureTime, String distance, String scheduledArrival,
			       String arrivalDelay) {
		this.year = year;
		this.month = month;
		this.day = day;
		this.dayOfWeek = dayOfWeek;
		this.airline = airline;
		this.flightNumber = flightNumber;
		this.originAirport = originAirport;
		this.destinationAirport = destinationAirport;
		this.scheduledDeparture = scheduledDeparture;
		this.departureTime = departureTime;
		this.distance = distance;
		this.scheduledArrival = scheduledArrival;
		this.arrivalDelay = arrivalDelay;	
	}
	
	/**
	 * Returns the distance traveled by each flight.
	 * @return distance distance traveled
	 */
	public String getDistance() {
		return distance;
	}

}
