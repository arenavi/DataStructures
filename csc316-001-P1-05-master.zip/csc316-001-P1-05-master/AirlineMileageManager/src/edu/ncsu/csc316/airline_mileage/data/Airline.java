package edu.ncsu.csc316.airline_mileage.data;

/**
 * Creates an airline object with description, IATA_CODE, callsign,
 * and country.
 * @author Amiya Renavikar
 */
public class Airline {
	
	/** Airline description. */
	private String description;
	/** Airline IATA CODE. */
	private String iataCode;
	/** Airline call sign. */
	@SuppressWarnings("unused")
	private String callSign;
	/** Airline country. */
	@SuppressWarnings("unused")
	private String country;
	
	/**
	 * Constructs an Airline object.
	 * @param description description of Airline
	 * @param iataCode IATA code of Airline
	 * @param callSign call sign of Airline
	 * @param country country of origin
	 */
	public Airline(String description, String iataCode, String callSign, String country) {
		this.description = description;
		this.iataCode = iataCode;
		this.callSign = callSign;
		this.country = country;
	}
	
	/**
	 * Returns the description of the airline.
	 * @return description description of airline
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Returns the IATA code of the airline.
	 * @return iataCode Iata code of airline
	 */
	public String getIataCode() {
		return iataCode;
	}
}
