package edu.ncsu.csc316.airline_mileage.manager;

import java.io.FileNotFoundException;

import edu.ncsu.csc316.airline_mileage.data.Airline;
import edu.ncsu.csc316.airline_mileage.data.Customer;
import edu.ncsu.csc316.airline_mileage.data.Flight;
import edu.ncsu.csc316.airline_mileage.io.AirlineReader;
import edu.ncsu.csc316.airline_mileage.io.CustomerReader;
import edu.ncsu.csc316.airline_mileage.io.FlightReader;
import edu.ncsu.csc316.airline_mileage.list.ArrayList;

/**
 * Handles the functionality of the mileage of the airline.
 * @author Amiya Renavikar
 */
public class AirlineMileageManager {
	
	/** Arraylist holding airline input. */
	private ArrayList<Airline> airlineList = new ArrayList<Airline>(100);
	/** Arraylist holding customer input. */
	private ArrayList<Customer> customerList = new ArrayList<Customer>(100);
	/** Arraylist holding flight input. */
	private ArrayList<Flight> flightList = new ArrayList<Flight>(20);;
	
    /**
	 * Constructs an AirlineMileageManager.
	 * 
	 * @param pathToAirlineFile - path to the airline information file
	 * @param pathToCustomerFile - path to the customer information file
	 * @param pathToFlightFile - path to the flight information file
	 */
	@SuppressWarnings("static-access")
	public AirlineMileageManager(String pathToAirlineFile, String pathToCustomerFile, String pathToFlightFile) {
		pathToAirlineFile = "/input/airline.txt";
		AirlineReader a = new AirlineReader("/input/airline.txt");
		try {
			airlineList = a.readAirline(pathToAirlineFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pathToCustomerFile = "/input/customer.txt";
		CustomerReader c = new CustomerReader("/input/customer.txt");
		try {
			customerList = c.readCustomer(pathToCustomerFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		pathToFlightFile = "/input/flight.txt";
		FlightReader f = new FlightReader("/input/flight.txt");
		try {
			flightList = f.readFlight(pathToFlightFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Produces the mileage report for all cardholders
	 * as a String, sorted alphabetically by cardholder
	 * last name.
	 * 
	 * @return the mileage report for all customers
	 */
	public String getMileageReport()
	{
		String mileageReport = "";
		Customer c1 = new Customer("", "", "", "", "", "");
		customerList.add(c1);
			for (int i = 0; i <= customerList.size() - 1; i++) {
				mileageReport += customerList.get(i).getFirstName() + 
					         customerList.get(i).getLastName() + 
					         " earned" + '\n';
			}

		Flight f1 = new Flight("", "", "", "", "", "", "", "", "", "", "", "", "");
		flightList.add(f1);
			for (int j = 0; j <= flightList.size() - 1; j++) {
				mileageReport += flightList.get(j).getDistance() + " miles with ";  
			}

		Airline a1 = new Airline("", "", "", "");
		airlineList.add(a1);
			for (int k = 0; k <= airlineList.size() - 1; k++) {
				mileageReport += airlineList.get(k).getDescription() + " (" + 
					         airlineList.get(k).getIataCode() + ")";				         
			}
		return mileageReport;
	}
	
	/**
	 * Retrieves the frequent flier mileage for the specified
	 * cardholder with the given first name and last name.
	 * Miles are listed in descending order by distance
	 * 
	 * @param firstName - the cardholder's first name
	 * @param lastName - the cardholder's last name
	 * @return the frequent flier mileage information for the cardholder
	 */
	public String getMiles(String firstName, String lastName) {
		Customer c1 = new Customer("" , "", "", "", "", "");
		customerList.add(c1);
		Flight f1 = new Flight("", "", "", "", "", "", "", "", "", "", "", "", "");
		flightList.add(f1);
		for (int i = 1; i < customerList.size() - 1; i++) {
			if(customerList.get(i).getFirstName().equals(firstName) &&
			   customerList.get(i).getLastName().equals(lastName)) {
				return flightList.get(i).getDistance();
				
			}
		}
	    return "Not found!";
	}
}
