/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.list;

import java.util.Arrays;

import edu.ncsu.csc316.airline_mileage.data.Customer;

/**
 * This class is based on the implementation of Arraylist for CSC 216 project 3/lab.
 * @author Amiya Renavikar, Joshua Cowles, Andrew Hensley 
 */
public class SortedCustomerArrayList {
	
	/** Default size of the arraylist */
	private static final int INIT_SIZE = 100;
	/** List containing customer objects */
	private Customer[] list;
//	/** Capacity of the arraylist */
//	private int capacity;
	/** Size of the arraylist */
	private int size;
	
	/**
	 * Creates a sorted array list with a capacity of 100 objects.
	 */
	public SortedCustomerArrayList() {
		list = new Customer[INIT_SIZE];
		size = 0;
	}

	/**
	 * Returns number of objects in ArrayList
	 * @return the number
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Returns the element at the passed-in parameter index.
	 * @param idx index of the element
	 * @return object at the specified index.
	 */
	public Customer get(int idx) {
		if (idx < 0 || idx > size - 1) {
			throw new IndexOutOfBoundsException();
		}
		return list[idx];
	}
	
	/**
	 * Doubles the size of the array
	 */
	void growArray() {
		int newCap = list.length * 2 + 1;
		list = Arrays.copyOf(list, newCap);
	}

	/**
	 * Adds a customer object.
	 * @param object the object to be added
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 * @throws NullPointerException if object is null
	 * @throws IllegalArgumentException if object is duplicate
	 */
	public void add(Customer object) {
		if (object == null) {
			throw new NullPointerException();
		}
//		if (idx > size || idx < 0) {
//			throw new IndexOutOfBoundsException();
//		}
		if (list.length == size) {
			growArray();
		}
		list[size] = object;
		size++;
	}
	
	/**
	 * Sets the element at index idx to Object object
	 * @param idx index to be set
	 * @param object object to be set
	 * @throws IndexOutOfBoundsException if index is out of bounds
	 * @throws NullPointerException if object is null
	 * @throws IllegalArgumentException if object is duplicate
	 */
	public void set(int idx, Customer object) {
		if (object == null) {
			throw new NullPointerException();
		}
		if (idx > size || idx < 0) {
			throw new IndexOutOfBoundsException();
		}
		list[idx] = object;		
	}

}