/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.io;

import java.io.File;

import java.io.FileNotFoundException;
import java.util.Scanner;

import edu.ncsu.csc316.airline_mileage.data.Flight;
import edu.ncsu.csc316.airline_mileage.list.ArrayList;

/**
 * Reads input from Flight input file.
 * @author Amiya Renavikar
 */
public class FlightReader {
	
	/** Stores the pathname to the flight input file. */
	private String pathToFlightFile;
	
	/**
	 * Constructs a FLightReader object.
	 * @param pathToFlightFile pathname to the flight input file
	 */
	public FlightReader(String pathToFlightFile) {
		setPathToFlightFile(pathToFlightFile);
	}

	/**
	 * Reads the input Flight file and returns an arraylist containing flight objects.
	 * @param pathToFlightFile path to flight input file
	 * @return flights Arraylist containing flight objects
	 * @throws FileNotFoundException if file is not found
	 */
	public static ArrayList<Flight> readFlight(String pathToFlightFile) throws FileNotFoundException {
		File input = new File(pathToFlightFile);

		if (!input.exists()) {
			throw new FileNotFoundException("Error finding file!");
		}
		//Create arraylist for Flight
		ArrayList<Flight> flights = new ArrayList<Flight>(100);
		//Try to read file
		try (Scanner file = new Scanner(input)) {
			while (file.hasNextLine()) {
				Scanner lineNum = new Scanner(file.nextLine());
			    //USe delimiter????
				lineNum.useDelimiter(",");
				String year = lineNum.next().trim();
				String month = lineNum.next().trim();
				String day = lineNum.next().trim();
				String dayOfWeek = lineNum.next().trim();
				String airline = lineNum.next().trim();
				String flightNumber = lineNum.next().trim();
				String originAirport = lineNum.next().trim();
				String destinationAirport = lineNum.next().trim();
				String scheduledDeparture = lineNum.next().trim();
				String departureTime = lineNum.next().trim();
				String distance = lineNum.next().trim();
				String scheduledArrival = lineNum.next().trim();
				String arrivalDelay = lineNum.next().trim();
				flights.add(new Flight(year, month, day, dayOfWeek, airline, flightNumber, originAirport,
						               destinationAirport, scheduledDeparture, departureTime, distance,
						               scheduledArrival, arrivalDelay));
				lineNum.close();
			}
			file.close();
		} catch (NumberFormatException e) {
			//do nothing
		}
		return flights;
	}

	/**
	 * Returns the path to the flight file.
	 * @return the pathToFlightFile path to flight file
	 */
	public String getPathToFlightFile() {
		return pathToFlightFile;
	}

	/**
	 * Sets the path to the flight file.
	 * @param pathToFlightFile path to flight file
	 */
	public void setPathToFlightFile(String pathToFlightFile) {
		this.pathToFlightFile = pathToFlightFile;
	}

}
