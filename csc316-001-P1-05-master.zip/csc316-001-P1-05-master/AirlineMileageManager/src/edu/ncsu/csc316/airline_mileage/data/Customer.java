/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.data;

/**
 * Creates a customer object with first name, last name, date of travel, flight number,
 * origin, destination of flight.
 * @author Amiya Renavikar
 */
public class Customer {
	/** First name of customer */
	private String firstName;
	/** Last name of customer */
	private String lastName;
	/** Customer's date of travel */
	@SuppressWarnings("unused")
	private String dateOfTravel;
	/** Customer's flight number */
	private String flightNum;
	/** Customer's flight origin location */
	@SuppressWarnings("unused")
	private String origin;
	/** Customer's flight destination location */
	@SuppressWarnings("unused")
	private String dest;
	
	/**
	 * Creates a customer object with first name, last name, date of travel, flight number,
     * origin, destination of flight.
	 * @param firstName first name of Customer
	 * @param lastName last name of Customer
	 * @param dateOfTravel Customer's date of travel
	 * @param flightNum Flight number
	 * @param origin Flight origin
	 * @param dest Flight destination
	 */
	public Customer (String firstName, String lastName, String dateOfTravel, String flightNum, String origin, String dest) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfTravel = dateOfTravel;
		this.flightNum = flightNum;
		this.origin = origin;
		this.dest = dest;
	}
	
	/**
	 * Returns the first name of the Customer.
	 * @return firstName first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Returns the last name of the Customer.
	 * @return lastName last name
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * Returns the flight name which is stored as the first
	 * 2 letters in the flight number.
	 * @return first 2 substrings of the flightNUm string
	 */
	public String getFlightNumName() {
		return flightNum.substring(0, 2);
	}
}
