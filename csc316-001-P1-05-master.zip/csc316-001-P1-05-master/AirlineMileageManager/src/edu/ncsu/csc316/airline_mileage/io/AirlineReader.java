/**
 * 
 */
package edu.ncsu.csc316.airline_mileage.io;

import java.io.File;

import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import edu.ncsu.csc316.airline_mileage.data.Airline;
import edu.ncsu.csc316.airline_mileage.list.ArrayList;

/**
 * Reads the airline input file.
 * @author Amiya Renavikar 
 */
public class AirlineReader {
	
	/** Stores the pathname to the airline input file. */
	private String pathToAirlineFile;
	
	/**
	 * Constructs an airline reader object.
	 * @param pathToAirlineFile pathname to the airline input file
	 */
	public AirlineReader(String pathToAirlineFile) {
		setPathToAirlineFile(pathToAirlineFile);
	}

	/**
	 * Sets the path to the airline file.
	 * @param pathToAirlineFile path to airline file
	 */
	private void setPathToAirlineFile(String pathToAirlineFile) {
		this.pathToAirlineFile = pathToAirlineFile;
	}

	/**
	 * Reads the input Airline file and returns an arraylist containing airline objects.
	 * @param pathToAirlineFile path to airline input file
	 * @return airlines Arraylist containing airline objects
	 * @throws FileNotFoundException when file is not found
	 */
	public static ArrayList<Airline> readAirline(String pathToAirlineFile) throws FileNotFoundException {
		File input = new File(pathToAirlineFile);
		if (!input.exists()) {
			throw new FileNotFoundException("Error finding file!");
		}
		
		//Create arraylist for Airline
		ArrayList<Airline> airlines = new ArrayList<Airline>(100);
		//Try to read file
		try (Scanner file = new Scanner(input)) {
			while (file.hasNextLine()) {
				Scanner lineNum = new Scanner(file.nextLine());
			    //USe delimiter????
				lineNum.useDelimiter(",");
				String description = lineNum.next().trim();
				String iataCode = lineNum.next().trim();
				String callSign = lineNum.next().trim();
				String country = lineNum.next().trim();
				airlines.add(new Airline(description, iataCode, callSign, country));
				lineNum.close();
			}
			file.close();
		} catch (NoSuchElementException e) {
			//do nothing
		}	
		return airlines;
	}

	/**
	 * Returns the path to the airline file.
	 * @return pathToAirlineFile path to the airline input file
	 */
	public String getPathToAirlineFile() {
		return pathToAirlineFile;
	}


}
