/**
 * 
 */
package edu.ncsu.csc316.customer_service.tree;

/**
 * @author amiyarenavikar
 *
 */
public interface Tree {

}
