/**
 * 
 */
package edu.ncsu.csc316.customer_service.data;

/**
 * Stores the information about the date and time when the HelpTicket was created. 
 * @author Amiya Renavikar
 */
public class TimeStamp {
	
	/** Date the HelpTicket was created */
	private String date;
	/** Month the HelpTicket was created */
	private String month;
	/** Year the HelpTicket was created */
	private String year;
	/** Hour the HelpTicket was created */
	private String hour;
	/** Minute the HelpTicket was created */
	private String minute;
	/** Second the HelpTicket was created */
	private String second;
	
	/**
	 * Constructs the TimeStamp object with month, date, year, hour, minute, and second fields.
	 * @param month Month the HelpTicket was created
	 * @param date Date the HelpTicket was created
	 * @param year Year the HelpTicket was created
	 * @param hour Hour the HelpTicket was created
	 * @param minute Minute the HelpTicket was created
	 * @param second Second the HelpTicket was created
	 */
	public TimeStamp(String month, String date, String year, String hour, String minute, String second) {
		this.month = month;
		this.date = date;
		this.year = year;
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}
	
	/**
	 * Returns the Date of the HelpTicket.
	 * @return date Date the HelpTicket was created
	 */
	public String getDate() {
		return date;
	}
	
	/**
	 * Returns the Month of the HelpTicket.
	 * @return month Month the HelpTicket was created
	 */
	public String getMonth() {
		return month;
	}
	
	/**
	 * Returns the Year of the HelpTicket.
	 * @return year Year the HelpTicket was created
	 */
	public String getYear() {
		return year;
	}
	
	/**
	 * Returns the Hour of the HelpTicket.
	 * @return hour Hour the HelpTicket was created
	 */
	public String getHour() {
		return hour;
	}
	
	/**
	 * Returns the Minute of the HelpTicket.
	 * @return minute Minute the HelpTicket was created
	 */
	public String getMinute() {
		return minute;
	}
	
	/**
	 * Returns the Second of the HelpTicket.
	 * @return second Second the HelpTicket was created
	 */
	public String getSecond() {
		return second;
	}
	
	//add compareto(TimeStamp)
}
