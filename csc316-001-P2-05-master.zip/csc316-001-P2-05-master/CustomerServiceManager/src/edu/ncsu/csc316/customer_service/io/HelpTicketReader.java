/**
 * 
 */
package edu.ncsu.csc316.customer_service.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import edu.ncsu.csc316.customer_service.data.HelpTicket;
import edu.ncsu.csc316.customer_service.data.TimeStamp;
import edu.ncsu.csc316.customer_service.tree.MultiPurposeTree;

/**
 * Reads in the input file that contains the help ticket information.
 * @author Amiya Renavikar
 */
public class HelpTicketReader {
	
	/** Stores the pathname to the help ticket input file. */
	private String pathToHelpTicketsFile; 
	
	/**
	 * Constructs a HelpTicket reader object.
	 * @param pathToHelpTicketsFile pathname to the HelpTicket input file
	 */
	public HelpTicketReader(String pathToHelpTicketsFile) {
		setPathToHelpTicketsFile(pathToHelpTicketsFile);
	}
	
	/**
	 * Sets the path to the HelpTicket file.
	 * @param pathToHelpTicketsFile path to HelpTicket file
	 */
	private void setPathToHelpTicketsFile(String pathToHelpTicketsFile) {
		this.pathToHelpTicketsFile = pathToHelpTicketsFile;
	}
	
	/**
	 * Returns the path to the HelpTicket file.
	 * @return the pathToHelpTicketsFile path to HelpTicket file.
	 */
	public String getPathToHelpTicketsFile() {
		return pathToHelpTicketsFile;
	}

	/**
	 * Reads the HelpTicket input file and stores data into the Multipurpose Tree.
	 * @param pathToHelpTicketsFile path to the input file
	 * @return m MultiPurpose tree that stores data
	 * @throws FileNotFoundException if file is not found
	 */
	public MultiPurposeTree<HelpTicket> readHelpTicket(String pathToHelpTicketsFile) throws FileNotFoundException {
		File input = new File(pathToHelpTicketsFile);
		if (!input.exists()) {
			throw new FileNotFoundException("Please re-enter file name!");
		}
		MultiPurposeTree<HelpTicket> m = new MultiPurposeTree<HelpTicket>();
		try (Scanner file = new Scanner(input)) {
			while (file.hasNextLine()) {
				Scanner lineNum = new Scanner(file.nextLine());
				lineNum.useDelimiter("/");
				String month = lineNum.next();
				String date = lineNum.next();
				lineNum.useDelimiter(" ");
				String year = lineNum.next();
				lineNum.useDelimiter(":");
				String hour = lineNum.next();
				String minute = lineNum.next();
				lineNum.useDelimiter(",");
				String second = lineNum.next();
				String priority = lineNum.next();
				String firstName = lineNum.next().trim();
				String lastName = lineNum.next().trim();
				String question = lineNum.next().trim();
				TimeStamp ts = new TimeStamp(month, date, year, hour, minute, second);
				HelpTicket h = new HelpTicket(ts, priority, firstName, lastName, question);
				m.insert(null, h);
				lineNum.close();
			}
			file.close();
		}
		return m;
	}
}
