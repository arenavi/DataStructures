/**
 * 
 */
package edu.ncsu.csc316.customer_service.tree;

/**
 * Contains the help tickets that have been read in from the input help ticket
 * information file.
 * @author Amiya Renavikar
 */
public class MultiPurposeTree<E> implements Comparable<E> {
	
	/** Stores the value at the root node of the tree. */
	@SuppressWarnings("unused")
	private Node root;
	
	/**
	 * Constructs a MultiPurposeTree object by setting the root to null.
	 */
	public MultiPurposeTree() {
		root = null;
	}
	
	/**
	 * Inserts a new Node into the Binary Search Tree.
	 * @param n Node
	 * @param data element to be inserted
	 * @return n Node that is inserted
	 */
	@SuppressWarnings("unchecked")
	public Node insert(Node n, E data) {
		if (n == null) {
			n = new Node(data);
		} else {
			if (((Comparable<E>) data).compareTo(n.getData()) > 0) {
				n.rightNode = insert(n.rightNode, data);
			} else if (((Comparable<E>) data).compareTo(n.getData()) < 0) {
				n.leftNode = insert(n.leftNode, data);
			} else {
				n = insert(n, data);
			}
		}
		return n;
	}
	
	/**
	 * Deletes a node from the Binary Search Tree.
	 * @param n Node 
	 * @param data element to be deleted
	 * @return n Node that is deleted
	 */
	@SuppressWarnings("unchecked")
	public Node remove(Node n, E data) {
		if (n != null) {
			if (data == null) {
				n.rightNode = remove(n.rightNode, data);
			} else {
				if (((Comparable<E>) data).compareTo(n.getData()) > 0) {
					n.rightNode = remove(n.rightNode, data);
				} else if (((Comparable<E>) data).compareTo(n.getData()) < 0) {
					n.leftNode = remove(n.leftNode, data);
				} else {
					n = remove(n, data);
				}
			}
		}
		return n;
	}
	
	/**
	 * Compares the data.
	 * @param data generic type
	 * @return 0
	 */
	@Override
	public int compareTo(E data) {
		return 0;
	}
	
	/**
	 * Searches for the specified node in the Binary Search Tree.
	 * @param n Node
	 * @param data element to be searched
	 * @return n found element
	 */
	@SuppressWarnings("unchecked")
	public Node lookUp(Node n, E data) {
		if (n != null) {
			if (((Comparable<E>) data).compareTo(n.getData()) == 0) {
				return lookUp(n, data);
			} else {
				if(((Comparable<E>) data).compareTo(n.getData()) > 0) {
					return lookUp(n.rightNode, data);
				} else if (((Comparable<E>) data).compareTo(n.getData()) < 0) {
					return lookUp(n.leftNode, data);
				}
			}
		} 
		return n;
	}
	
	/**
	 * Inner class that creates Node objects.
	 * @author Amiya Renavikar
	 */
	private class Node {
		
		/** Left child of the node */
		private Node leftNode;
		/** Right child of the node */
		private Node rightNode;
        /** Generic data of the node */
		private E data;
		
		/**
		 * Constructs a Node object with respective keys and nodes.
		 * @param leftNode Left child of the node
		 * @param rightNode Right child of the node
		 * @param data data field
		 */
		public Node(E data) {
			this.leftNode = null;
			this.rightNode = null;
			this.data = data;
		}
		
		/**
		 * Returns the data from the node.
		 * @return data data from node
		 */
		public E getData() {
			return data;
		}
		
		/**
		 * Returns the right from the node.
		 * @return rightNode right from the node
		 */
		@SuppressWarnings("unused")
		public Node getRightNode() {
			return rightNode;
		}
		
		/**
		 * Returns the left from the node.
		 * @return leftNode left from the node
		 */
		@SuppressWarnings("unused")
		public Node getLeftNode() {
			return leftNode;
		}
		
	}

}
