/**
 * 
 */
package edu.ncsu.csc316.customer_service.data;

/**
 * 
 * @author Amiya Renavikar
 */
public class HelpTicket {
	
	/** Date and time of HelpTicket */
	@SuppressWarnings("unused")
	private TimeStamp time;
	/** Customer's priority */
	private String priority;
	/** First name of Customer */
	private String firstName;
	/** Last name of Customer */
	private String lastName;
	/** Reason for raising the help ticket */
	@SuppressWarnings("unused")
	private String question;
	/** Customer's position in the queue */
	private int position;
	
	/**
	 * Constructs a HelpTicket object by constructing all the help ticket fields.s
	 * @param ts Date and time of HelpTicket
	 * @param firstName Customer's priority
	 * @param lastName Customer that the help ticket belongs to
	 * @param question Reason for raising the help ticket
	 */
	public HelpTicket(TimeStamp ts, String priority, String firstName, String lastName, String question) {
		this.time = ts;
		this.priority = priority;
		this.firstName = firstName;
		this.lastName = lastName;
		this.question = question;
	}

	/**
	 * Returns the priority of the help ticket.
	 * @return priority priority of the help ticket
	 */
	public String getPriority() {
		return priority;
	}
	
	/**
	 * Returns the first name of the customer.
	 * @return firstName first name of the customer
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * Returns the last name of the customer.
	 * @return lastName last name of the customer
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * Returns the position of the customer in the queue.
	 * @return position position of the customer in the queue
	 */
	public int getPosition() {
		return position;
	}

}
