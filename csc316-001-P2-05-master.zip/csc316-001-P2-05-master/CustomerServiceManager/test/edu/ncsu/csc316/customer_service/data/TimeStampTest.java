/**
 * 
 */
package edu.ncsu.csc316.customer_service.data;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the TimeStamp class.
 * @author Amiya Renavikar
 */
public class TimeStampTest {

	/**
	 * Tests all the methods in the TimeStamp class.
	 */
	@Test
	public void testTimeStamp() {
		TimeStamp ts = new TimeStamp("09", "03", "2017", "10", "00", "00");
		assertNotNull(ts);
		assertEquals("09", ts.getMonth());
		assertEquals("03", ts.getDate());
		assertEquals("2017", ts.getYear());
		assertEquals("10", ts.getHour());
		assertEquals("00", ts.getMinute());
		assertEquals("00", ts.getSecond());
	}

}
