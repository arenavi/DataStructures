/**
 * 
 */
package edu.ncsu.csc316.customer_service.data;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Tests the HelpTicket class.
 * @author Amiya renavikar
 */
public class HelpTicketTest {

	/**
	 * Tests all the methods in the HelpTicket class.
	 */
	@Test
	public void test() {
		TimeStamp ts = new TimeStamp("09", "03", "2017", "10", "00", "00");
		HelpTicket ht = new HelpTicket(ts, "5", "Suzanne", "Smith", "How do I check my mileage balance?");
		assertNotNull(ht);
		assertEquals("5", ht.getPriority());
		assertEquals("Suzanne", ht.getFirstName());
		assertEquals("Smith", ht.getLastName());
	}

}
