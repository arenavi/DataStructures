/**
 * 
 */
package edu.ncsu.csc316.customer_service.io;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Test;

import edu.ncsu.csc316.customer_service.data.HelpTicket;
import edu.ncsu.csc316.customer_service.tree.MultiPurposeTree;


/**
 * Tests the HelpTicketReader class.
 * @author Amiya Renavikar
 */
public class HelpTicketReaderTest {

	@Test
	public void test() {
		HelpTicketReader ar = null;
		assertNull(ar);
		ar = new HelpTicketReader("input/helpticket.txt");
		assertNotNull(ar);
		assertEquals("input/helpticket.txt", ar.getPathToHelpTicketsFile());
//		try {
//			MultiPurposeTree<HelpTicket> mpt = ar.readHelpTicket("input/helpticket.txt");
//			assertNotNull(mpt);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//
//		}
	}

}
